// xxxxxxxxxx Working For Login and Fetching All Details xxxxxxxxxx

//Create User Pin
function createUserPin(){
    var dt = new Date().getTime();
    var uuid = 'xxxx-xxxx-4xxx-yxxx-xxxx'.replace(/[xy]/g, function(c) {
        var r = (dt + Math.random()*16)%16 | 0;
        dt = Math.floor(dt/16);
        return (c=='x' ? r :(r&0x3|0x8)).toString(16);
    });
    return uuid;
}

function createNull(){
  var dt = new Date().getTime();
    var uuid = 'xxxx'.replace(/[xy]/g, function(c) {
        var r = (dt + Math.random()*16)%16 | 0;
        dt = Math.floor(dt/16);
        return (c=='x' ? r :(r&0x3|0x8)).toString(16);
    });
    return uuid;
}

// xxxxxxxxxx Sign In Email Validation xxxxxxxxxx
function checkUserSIEmail(){
    var userSIEmail = document.getElementById("userSIEmail");
    var userSIEmailFormate = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var flag;
    if(userSIEmail.value.match(userSIEmailFormate)){
        flag = false;
    }else{
        flag = true;
    }
    if(flag){
        document.getElementById("userSIEmailError").style.display = "block";
    }else{
        document.getElementById("userSIEmailError").style.display = "none";
    }
}
// xxxxxxxxxx Sign In Password Validation xxxxxxxxxx
function checkUserSIPassword(){
    var userSIPassword = document.getElementById("userSIPassword");
    var userSIPasswordFormate = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{10,}/;      
    var flag;
    if(userSIPassword.value.match(userSIPasswordFormate)){
        flag = false;
    }else{
        flag = true;
    }    
    if(flag){
        document.getElementById("userSIPasswordError").style.display = "block";
    }else{
        document.getElementById("userSIPasswordError").style.display = "none";
    }
}
// xxxxxxxxxx Check email or password exsist in firebase authentication xxxxxxxxxx    
function signIn() {
    var userSIEmail = document.getElementById("userSIEmail").value;
    var userSIPassword = document.getElementById("userSIPassword").value;
    var userSIEmailFormate = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var userSIPasswordFormate = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{10,}/;

    var checkUserEmailValid = userSIEmail.match(userSIEmailFormate);
    var checkUserPasswordValid = userSIPassword.match(userSIPasswordFormate);

    if (checkUserEmailValid == null) {
        return checkUserSIEmail();
    } else if (checkUserPasswordValid == null) {
        return checkUserSIPassword();
    } else {
        firebase.auth().signInWithEmailAndPassword(userSIEmail, userSIPassword).then((success) => {
            swal({
                type: 'successfull',
                title: 'Succesfully signed in',
            }).then((value) => {
                setTimeout(function () {
                    window.location.replace("home_dasgboard.html");
                }, 1000)
            });
        }).catch((error) => {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            swal({
                type: 'error',
                title: 'Error',
                text: "Error",
            })
        });
    }
}


//fetching Details
var firebaseRef = firebase.database().ref("All-Users").child("Subscribe Registered Users")
         .limitToLast(30)	
         .once('value', function(snapshot){
             if(snapshot.exists()){
                 var content = '';
                 snapshot.forEach(function(data){                     
                         var val = data.val();
                         content +='<tr>';
                         content += '<td>' + val.userId + '</td>';
                         content += '<td>' + val.userFullName + '</td>';
                         content += '<td>' + val.userMobile + '</td>';
                         content += '<td>' + val.userEmail + '</td>'; 
                         content += '<td>' + val.userAddress + '</td>';                         
                         content += '<td>' + val.userMessage + '</td>';     
                         
                         content += '</tr>';
                     
                 });
                 $('#alter').append(content);
			
             }
         });
  //profile show

// xxxxxxxxxx Get data from server and show in the page xxxxxxxxxx
firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        //   User is signed in.
        var user = firebase.auth().currentUser;
        var uid;
        if (user != null) {
            uid = user.uid;
        }
        var firebaseRefKey = firebase.database().ref("All-Users").child("Subscribe Registered Users").child(uid);
        firebaseRefKey.on('value', (dataSnapShot) => {
          //  document.getElementById("fname").innerHTML = dataSnapShot.val().userFullName;
          //  document.getElementById("femail").innerHTML = dataSnapShot.val().userEmail;
          //  document.getElementById("faddress").innerHTML = dataSnapShot.val().userAddress;
          //  document.getElementById("fmessage").innerHTML = dataSnapShot.val().userMessage;
            document.getElementById("fMobile").innerHTML = dataSnapShot.val().userMobile;

        })
    } else {
        //   No user is signed in.
    }
});

  //Forgot Password
  $("#btn-resetPassword").click(function()
  {
	  var auth = firebase.auth();
	  var email = $("#email").val();
	  if(email != "")
	  {
		  auth.sendPasswordResetEmail(email).then(function()		  
		  {
			swal({
            type: 'successfull',
            title: 'Change Password successfull',
            text: 'Your New Password has been changed successfully', 
        }).then((value) => {
            setTimeout(function(){
                window.location.replace("index.html");
            }, 1000)
        });
	  }).catch(function(error)
		  {			
	       var errorMessage=error.message;
			swal({
            type: 'error',
            title: 'Error',
            text: "Error",
        })		   
	    });
	  }
	  else{
		window.alert("Please write your email first");  
	  }
  });


// xxxxxxxxxx Working For Sign Out xxxxxxxxxx
function signOut(){
    firebase.auth().signOut().then(function() {
        // Sign-out successful.
        swal({
            type: 'successfull',
            title: 'Signed Out', 
        }).then((value) => {
            setTimeout(function(){
                window.location.replace("index.html");
            }, 1000)
        });
    }).catch(function(error) {
        // An error happened.
        let errorMessage = error.message;
        swal({
            type: 'error',
            title: 'Error',
            text: "Error",
        })
    });
}

