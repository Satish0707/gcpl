// Initialize Firebase (ADD YOUR OWN DATA)
// Reference messages collection
var firebaseConfig = {
    apiKey: "AIzaSyA063-ngsexQ0rhIvtHRKP0LmB0yBrH5vk",
    authDomain: "oneclick-73406.firebaseapp.com",
    databaseURL: "https://oneclick-73406.firebaseio.com",
    projectId: "oneclick-73406",
    storageBucket: "oneclick-73406.appspot.com",
    messagingSenderId: "69122383434",
    appId: "1:69122383434:web:ed374155a50b23b0a610b3"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Listen for form submit
document.getElementById('contactForm').addEventListener('submit', submitForm);

// Submit form
function submitForm(e) {
    e.preventDefault();

    // Get values
    var userFullName = getInputVal('fname');
    var userEmail = getInputVal('femail');
    var userAddress = getInputVal('faddress');
    var userMessage = getInputVal('fmessage');
    //var userPhone = getInputVal('fphone');

    // Save message
    saveMessage(userFullName, userEmail, userAddress, userMessage);

    // Show alert
    document.querySelector('.alert').style.display = 'block';

    // Hide alert after 3 seconds
    setTimeout(function () {
        document.querySelector('.alert').style.display = 'none';
    }, 3000);

    // Clear form
    document.getElementById('contactForm').reset();


    // Function to get get form values
    function getInputVal(id) {
        return document.getElementById(id).value;
    }

    // Save message to firebase
    function saveMessage() {
        //  let userFullName = document.getElementById("fname").value
        //  let userEmail = document.getElementById("femail").value
        //  let userAddress = document.getElementById("faddress").value
        //   let userMessage = document.getElementById("fmessage").value

        let user = firebase.auth().currentUser;
        let uid;
        if (user != null) {
            uid = user.uid;
        }
        var firebaseRef = firebase.database().ref("All-Users").child("Subscribe Registered Users");
        var userData = {
            userFullName: userFullName,
            userEmail: userEmail,
            userAddress: userAddress,
            userMessage: userMessage,
        }
        firebaseRef.child(uid).update(userData);
        swal({
            type: 'successfull',
            title: 'sending successfull',
            text: 'Enquiry Send.',
        }).then((value) => {
            setTimeout(function () {
                window.location.replace("Home.html");
            }, 1000)
        });
    }
}
