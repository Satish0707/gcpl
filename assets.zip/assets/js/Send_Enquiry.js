﻿// Initialize Firebase (ADD YOUR OWN DATA)
//update PH Sending Details
function sendEnquiry() {
    let userFullName = document.getElementById("fname").value
    let userEmail = document.getElementById("femail").value
    let userAddress = document.getElementById("faddress").value
    let userMessage = document.getElementById("fmessage").value

    let user = firebase.auth().currentUser;
    let uid;
    if (user != null) {
        uid = user.uid;
    }
    var firebaseRef = firebase.database().ref().child("All-Users").child("Subscribe Registered Users");
    var userData = {
        userFullName: userFullName,
        userEmail: userEmail,
        userAddress: userAddress,
        userMessage: userMessage,
    }
    firebaseRef.child(uid).push(userData);
    swal({
        type: 'successfull',
        title: 'sending successfull',
        text: 'Enquiry Send.',
    }).then((value) => {
        setTimeout(function () {
            window.location.replace("Home.html");
        }, 1000)
    });
}